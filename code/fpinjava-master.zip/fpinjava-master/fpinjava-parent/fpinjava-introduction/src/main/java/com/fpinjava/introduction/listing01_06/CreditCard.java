package com.fpinjava.introduction.listing01_06;

public class CreditCard {

	public void charge(int price) {
		// Charge the credit card
	}

}
