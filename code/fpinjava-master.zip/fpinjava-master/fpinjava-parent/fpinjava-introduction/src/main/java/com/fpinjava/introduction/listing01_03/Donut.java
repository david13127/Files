package com.fpinjava.introduction.listing01_03;

public class Donut {
	
	public static final int price = 2;

}
