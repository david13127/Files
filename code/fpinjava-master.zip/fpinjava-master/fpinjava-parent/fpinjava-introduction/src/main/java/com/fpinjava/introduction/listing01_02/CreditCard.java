package com.fpinjava.introduction.listing01_02;

public class CreditCard {

  public void charge(int price) {
    // Charge the credit card
  }

}
