package com.fpinjava.introduction.listing01_04;

public class CreditCard {

	public void charge(int price) {
		// Charge the credit card
	}

}
