package com.fpinjava.introduction.listing01_03;

public class CreditCard {

	public void charge(int price) {
		// Charge the credit card
	}

}
