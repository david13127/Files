package com.fpinjava.introduction.listing01_02;

public class Donut {

  public static final int price = 2;

}
