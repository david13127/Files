package com.fpinjava.application.listing15_04;


public enum Type {
  SERIAL,
  PARALLEL
}
