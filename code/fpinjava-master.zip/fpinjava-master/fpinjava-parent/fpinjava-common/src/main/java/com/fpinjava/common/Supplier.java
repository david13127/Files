package com.fpinjava.common;

public interface Supplier<T> {
  T get();
}