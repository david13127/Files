package com.fpinjava.common;


public interface Executable {

  void exec();
}
