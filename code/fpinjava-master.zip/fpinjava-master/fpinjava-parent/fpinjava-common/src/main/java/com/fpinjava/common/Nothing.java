package com.fpinjava.common;


public final class Nothing {
  public static final Nothing instance = new Nothing();
  private Nothing() {}
}