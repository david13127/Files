package com.fpinjava.actor;

import org.junit.Test;


public class ActorTest {

  @Test
  public void test() {}
}
