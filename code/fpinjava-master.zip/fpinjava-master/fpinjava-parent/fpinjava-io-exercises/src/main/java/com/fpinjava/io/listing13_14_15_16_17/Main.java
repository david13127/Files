package com.fpinjava.io.listing13_14_15_16_17;


public class Main {

  public static void main(String... args) {
    // IO.forever(Console.printLine("Hi...")).run();

    // IO program = IO.forever(IO.unit("Hi again!")
    //                           .flatMap(Console::printLine));
    // program.run();

    // IO.repeat(100000, Console.printLine("Hi...")).run();

    // IO.doWhile(Console.printLine("Hi..."), x -> IO.unit(true)).run();
  }
}
