package com.fpinjava.io.exercise13_04;


public class ReadFile {

  // adjust the path variable as needed
  private static String path = "data.txt";

  public static void main(String... args) {
    throw new IllegalStateException("To be implemented");
  }
}
