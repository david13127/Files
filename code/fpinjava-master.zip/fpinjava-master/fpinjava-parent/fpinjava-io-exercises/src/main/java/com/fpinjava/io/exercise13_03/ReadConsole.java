package com.fpinjava.io.exercise13_03;


public class ReadConsole {

  public static void main(String... args) {
    throw new IllegalStateException("To be implemented");
  }
}
